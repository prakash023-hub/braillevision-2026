import json, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

with open('/home/claude/braillevision/output/demo_data.json') as f:
    data = json.load(f)

js_items = []
for word, d in data.items():
    js_items.append(f"""  {{
    word: '{word}',
    raw: 'data:image/png;base64,{d["raw"]}',
    annotated: 'data:image/png;base64,{d["annotated"]}',
    dots: {d['dots']},
    decoded: '{d["decoded"]}',
    confidence: '{d["confidence"]}'
  }}""")

js_data = ',\n'.join(js_items)

html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BrailleVision — Real-time Physical Braille to English</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Segoe UI',system-ui,sans-serif;background:#f8f9fa;color:#1a1a2e;line-height:1.6}}
.hero{{background:#1a56db;color:white;padding:60px 20px;text-align:center}}
.hero h1{{font-size:3rem;font-weight:700;margin-bottom:12px}}
.hero p{{font-size:1.25rem;opacity:0.9;max-width:600px;margin:0 auto 24px}}
.badge{{display:inline-block;background:rgba(255,255,255,0.2);padding:6px 16px;border-radius:20px;font-size:0.85rem;margin:4px}}
.container{{max-width:900px;margin:0 auto;padding:40px 20px}}
.section-title{{font-size:1.6rem;font-weight:600;margin-bottom:24px;color:#1a1a2e;border-left:4px solid #1a56db;padding-left:14px}}
.pipeline{{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:40px;align-items:center}}
.pipe-step{{background:white;border:1px solid #e1e8f0;border-radius:8px;padding:12px 16px;flex:1;min-width:120px;text-align:center}}
.pipe-step .num{{font-size:0.75rem;color:#1a56db;font-weight:600;letter-spacing:1px}}
.pipe-step .label{{font-size:0.9rem;font-weight:500;margin-top:4px}}
.pipe-arrow{{color:#aaa;font-size:1.2rem}}
.demo-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin-bottom:24px}}
.demo-card{{background:white;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);cursor:pointer;transition:transform 0.2s,box-shadow 0.2s;border:2px solid transparent}}
.demo-card:hover{{transform:translateY(-3px);box-shadow:0 6px 24px rgba(0,0,0,0.12)}}
.demo-card.active{{border-color:#1a56db}}
.demo-card img{{width:100%;height:130px;object-fit:cover}}
.demo-card .card-body{{padding:14px}}
.demo-card .word-label{{font-weight:600;font-size:1rem;margin-bottom:4px}}
.demo-card .meta{{font-size:0.8rem;color:#666;margin-bottom:8px}}
.demo-card .decoded{{font-family:monospace;background:#f0f9f0;color:#0a5c2a;padding:6px 10px;border-radius:6px;border-left:3px solid #22c55e;font-size:1rem}}
.detail-panel{{background:white;border-radius:12px;padding:28px;box-shadow:0 2px 12px rgba(0,0,0,0.08);margin-bottom:40px;display:none}}
.detail-panel.visible{{display:block}}
.before-after{{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px}}
.before-after img{{width:100%;border-radius:8px;border:1px solid #e1e8f0}}
.before-after h3{{font-size:0.95rem;font-weight:600;margin-bottom:8px;color:#555}}
.result-box{{background:#f0f9f0;border:1px solid #22c55e;border-radius:8px;padding:20px;text-align:center;margin-bottom:16px}}
.result-text{{font-size:2rem;font-family:monospace;font-weight:700;color:#0a5c2a;letter-spacing:6px}}
.result-meta{{font-size:0.85rem;color:#555;margin-top:8px}}
.stats{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}}
.stat-card{{background:#f8f9fa;border-radius:8px;padding:14px;text-align:center}}
.stat-card .val{{font-size:1.6rem;font-weight:700;color:#1a56db}}
.stat-card .lbl{{font-size:0.75rem;color:#888;margin-top:2px}}
.conf-high{{color:#22c55e !important}}.conf-medium{{color:#f59e0b !important}}.conf-low{{color:#ef4444 !important}}
.feature-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:40px}}
.feature-card{{background:white;border-radius:10px;padding:20px;box-shadow:0 1px 6px rgba(0,0,0,0.06)}}
.feature-card .icon{{font-size:1.8rem;margin-bottom:10px}}
.feature-card h4{{font-size:0.95rem;font-weight:600;margin-bottom:6px}}
.feature-card p{{font-size:0.85rem;color:#555}}
.tech-stack{{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:40px}}
.tech-badge{{background:#e8eeff;color:#1a56db;padding:6px 14px;border-radius:20px;font-size:0.85rem;font-weight:500}}
.footer{{background:#1a1a2e;color:#aaa;text-align:center;padding:30px;font-size:0.9rem}}
@media(max-width:600px){{.hero h1{{font-size:2rem}}.before-after{{grid-template-columns:1fr}}}}
</style>
</head>
<body>

<div class="hero">
  <h1>&#128065; BrailleVision</h1>
  <p>Real-time physical Braille to English using camera-based AI</p>
  <span class="badge">&#127942; BrailleVision Hackathon 2026</span>
  <span class="badge">&#9855; Assistive Technology</span>
  <span class="badge">&#128065; Computer Vision</span>
  <span class="badge">&#127897; Text-to-Speech</span>
</div>

<div class="container">

  <h2 class="section-title">Detection Pipeline</h2>
  <div class="pipeline">
    <div class="pipe-step"><div class="num">01</div><div class="label">Camera Input</div></div>
    <div class="pipe-arrow">&#8594;</div>
    <div class="pipe-step"><div class="num">02</div><div class="label">CLAHE + Threshold</div></div>
    <div class="pipe-arrow">&#8594;</div>
    <div class="pipe-step"><div class="num">03</div><div class="label">Dot Detection</div></div>
    <div class="pipe-arrow">&#8594;</div>
    <div class="pipe-step"><div class="num">04</div><div class="label">Cell Segmentation</div></div>
    <div class="pipe-arrow">&#8594;</div>
    <div class="pipe-step"><div class="num">05</div><div class="label">Pattern &#8594; Text</div></div>
    <div class="pipe-arrow">&#8594;</div>
    <div class="pipe-step"><div class="num">06</div><div class="label">Speech Output</div></div>
  </div>

  <h2 class="section-title">Live Demo &#8212; Click to Inspect</h2>
  <div class="demo-grid" id="demo-grid"></div>

  <div class="detail-panel" id="detail-panel">
    <div class="before-after">
      <div>
        <h3>Raw Braille Image</h3>
        <img id="detail-raw" src="" alt="Raw Braille">
      </div>
      <div>
        <h3>After Dot Detection</h3>
        <img id="detail-ann" src="" alt="Annotated">
        <p style="font-size:0.8rem;color:#888;margin-top:6px">Green circles = detected Braille dots</p>
      </div>
    </div>
    <div class="result-box">
      <div class="result-text" id="detail-text"></div>
      <div class="result-meta" id="detail-meta"></div>
    </div>
    <div class="stats">
      <div class="stat-card"><div class="val" id="d-dots">-</div><div class="lbl">Dots detected</div></div>
      <div class="stat-card"><div class="val" id="d-chars">-</div><div class="lbl">Characters decoded</div></div>
      <div class="stat-card"><div class="val" id="d-conf">-</div><div class="lbl">Confidence</div></div>
    </div>
  </div>

  <h2 class="section-title">Accessibility Features</h2>
  <div class="feature-grid">
    <div class="feature-card">
      <div class="icon">&#128266;</div>
      <h4>Auto Text-to-Speech</h4>
      <p>Decoded text is read aloud automatically using gTTS with offline pyttsx3 fallback.</p>
    </div>
    <div class="feature-card">
      <div class="icon">&#128247;</div>
      <h4>Webcam Support</h4>
      <p>Live webcam capture directly in browser. No app installation required for end users.</p>
    </div>
    <div class="feature-card">
      <div class="icon">&#128161;</div>
      <h4>Camera Guidance</h4>
      <p>Built-in tips for optimal lighting and angle. Raking light technique explained in UI.</p>
    </div>
    <div class="feature-card">
      <div class="icon">&#9855;</div>
      <h4>High Contrast UI</h4>
      <p>Large text output, high-contrast green dot overlays, and accessible colour palette.</p>
    </div>
    <div class="feature-card">
      <div class="icon">&#128138;</div>
      <h4>Medical Use Case</h4>
      <p>Designed for caregivers reading Braille medication notes and prescription labels.</p>
    </div>
    <div class="feature-card">
      <div class="icon">&#128202;</div>
      <h4>Confidence Score</h4>
      <p>High / medium / low confidence so users know when to retake the photo.</p>
    </div>
  </div>

  <h2 class="section-title">Technology Stack</h2>
  <div class="tech-stack">
    <span class="tech-badge">Python 3.9+</span>
    <span class="tech-badge">OpenCV 4.x</span>
    <span class="tech-badge">NumPy</span>
    <span class="tech-badge">Gradio</span>
    <span class="tech-badge">gTTS</span>
    <span class="tech-badge">pyttsx3</span>
    <span class="tech-badge">Pillow</span>
    <span class="tech-badge">Grade 1 Braille (64 patterns)</span>
    <span class="tech-badge">CLAHE Enhancement</span>
    <span class="tech-badge">Adaptive Threshold</span>
    <span class="tech-badge">Contour Detection</span>
    <span class="tech-badge">Gap-based Segmentation</span>
  </div>

</div>

<div class="footer">
  BrailleVision Hackathon 2026 &nbsp;&bull;&nbsp; Assistive Technology for Visually Impaired Users &nbsp;&bull;&nbsp; Open Source
</div>

<script>
const DEMO_DATA = [
{js_data}
];

function buildCards() {{
  const grid = document.getElementById('demo-grid');
  DEMO_DATA.forEach((d, i) => {{
    const card = document.createElement('div');
    card.className = 'demo-card' + (i===0?' active':'');
    card.innerHTML = '<img src="' + d.annotated + '" alt="Braille ' + d.word + '">' +
      '<div class="card-body">' +
      '<div class="word-label">"' + d.word + '"</div>' +
      '<div class="meta">' + d.dots + ' dots detected &nbsp;&middot;&nbsp; ' + d.confidence + ' confidence</div>' +
      '<div class="decoded">&#8594; ' + d.decoded + '</div>' +
      '</div>';
    card.addEventListener('click', () => showDetail(i));
    grid.appendChild(card);
  }});
}}

function showDetail(idx) {{
  const d = DEMO_DATA[idx];
  document.querySelectorAll('.demo-card').forEach((c,i) => c.classList.toggle('active', i===idx));
  document.getElementById('detail-raw').src = d.raw;
  document.getElementById('detail-ann').src = d.annotated;
  document.getElementById('detail-text').textContent = d.decoded;
  document.getElementById('detail-meta').textContent = 'Decoded from "' + d.word + '" Braille \u2014 ' + d.dots + ' dots detected, ' + d.confidence + ' confidence';
  document.getElementById('d-dots').textContent = d.dots;
  document.getElementById('d-chars').textContent = d.decoded.replace(/\s/g,'').length;
  const confEl = document.getElementById('d-conf');
  confEl.textContent = d.confidence;
  confEl.className = 'val conf-' + d.confidence;
  const panel = document.getElementById('detail-panel');
  panel.classList.add('visible');
  panel.scrollIntoView({{behavior:'smooth', block:'nearest'}});
}}

buildCards();
showDetail(0);
</script>
</body>
</html>"""

with open('/home/claude/braillevision/output/project_demo.html', 'w') as f:
    f.write(html)

size_kb = len(html) // 1024
print(f'project_demo.html: {size_kb} KB')
